# Website Ryanezer Natan — Versi Statis

Kode ini sama persis dengan tampilan website yang ada di preview, dalam bentuk
HTML/CSS/JS murni (tanpa framework) supaya mudah dibuka di VS Code.

## Cara PALING MUDAH (1 file saja)
Buka `index-all-in-one.html` — semua CSS & JS sudah ada di dalamnya.
Cukup double-click file itu. Tab browser harus bertuliskan
"Ryanezer Natan | Musisi & Tutor Musik". Kalau tab hanya bertuliskan
"index.html" dan layar putih, berarti file yang dibuka KOSONG (belum disimpan).

## Cara menjalankan (versi 3 file)
1. Salin 3 file ini (`index.html`, `style.css`, `script.js`) ke satu folder.
2. Buka `index.html` di browser (cukup double-click) — tidak perlu install apa pun.
3. Untuk pengalaman terbaik, jalankan lewat Live Server (ekstensi VS Code) atau:
   `python3 -m http.server` lalu buka http://localhost:8000

## Struktur
- `index.html` — seluruh halaman (hero, marquee, tentang, keahlian, pencapaian, kontak + 3 modal)
- `style.css`  — seluruh styling & animasi
- `script.js`  — bintang berkelip, efek navbar, reveal saat scroll, tilt galaksi, logika modal

## Catatan
- Foto & video dimuat dari CDN (customer-assets.emergentagent.net). Jika ingin
  offline, unduh filenya, simpan di folder `assets/`, lalu ganti URL di `index.html`.
- Nomor HP memakai link WhatsApp: https://wa.me/6282113393529
  (ganti ke `tel:+6282113393529` bila ingin langsung menelpon).
